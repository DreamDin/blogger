<li class="gridlove-actions-button">
	<span class="gridlove-sidebar-action">
		<i class="fa fa-bars"></i>
	</span>
</li>