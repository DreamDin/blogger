<div id="gridlove-header-sticky" class="gridlove-header-sticky">
	<div class="container">
		
		<div class="gridlove-slot-l">
			<?php $logo = gridlove_get_option('logo_mini') && gridlove_get_option('header_sticky_logo') == 'mini' ? 'logo-mini' : 'logo'; ?>
			<?php get_template_part('template-parts/header/elements/'.$logo); ?>
		</div>	
		<div class="gridlove-slot-r">
			<?php get_template_part('template-parts/header/elements/main-menu'); ?>     
			<?php get_template_part('template-parts/header/elements/actions'); ?>
		</div>
	</div>
</div>