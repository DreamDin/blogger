<?php get_template_part('template-parts/page/entry-media'); ?> 
                        
<div class="box-inner-p-bigger box-single">
	
	<div class="text-center">
	    <?php get_template_part('template-parts/page/entry-header'); ?>
	</div>

    <?php get_template_part('template-parts/page/entry-content'); ?>


</div>