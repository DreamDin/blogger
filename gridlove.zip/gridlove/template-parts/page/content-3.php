<div class="box-single">
    <div class="entry-overlay-wrapper">
        <?php get_template_part('template-parts/page/entry-media'); ?>
        <div class="entry-overlay overlay-vh-center text-center">
            <?php get_template_part('template-parts/page/entry-header'); ?>
        </div>
    </div>
    <div class="box-inner-p-bigger">
        <?php get_template_part('template-parts/page/entry-content'); ?>
    </div>
</div>
