<div class="gridlove-header-4">
	<div class="gridlove-header-wrapper">
	<div class="gridlove-header-middle">
		<div class="gridlove-slot-c">
			<?php get_template_part('template-parts/header/elements/logo'); ?>
		</div>
	</div>
	</div>
	<div class="gridlove-header-bottom">
		<div class="gridlove-slot-c">
			<?php get_template_part('template-parts/header/elements/main-menu'); ?>
			<?php get_template_part('template-parts/header/elements/actions'); ?>
		</div>
	</div>
</div>