<?php get_template_part('template-parts/page/entry-media'); ?> 
                        
<div class="box-inner-p-bigger box-single">

    <?php get_template_part('template-parts/page/entry-header'); ?>

    <?php get_template_part('template-parts/page/entry-content'); ?>

</div>